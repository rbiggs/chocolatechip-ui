var ko = window["ko"] = {};
