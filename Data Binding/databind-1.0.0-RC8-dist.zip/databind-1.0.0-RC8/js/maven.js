/*
 * databind 1.0.0-RC8
 *
 * Copyright 2009 Arnd Brusdeilins <arnd@brusdeilins.net>
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 *
 */


jsBind.addEnumType("Scope",{
	runtime: "Runtime",
	compile: "Compile"
});

	
jsBind.addType("Property",{
	label: "Property",
	properties: {
		key: { type: "string"},
		value: { type: "string" }
	}
});

		jsBind.addType("Model",{
	properties: {
		pomVersion: {
			required: true,
			type: "string",
			description: "Declares to which version of project descriptor this POM conforms. The only valid value is <code>3</code>."
		},
		modelVersion: {
			required: true,
			type: "string",
			description: "Declares to which version of project descriptor this POM conforms."
		},
		extend: {
			required: false,
			type: "string",
			description: "The location of the parent project, if one exists. Values from the parent project will be the default for this project if they are left unspecified. The path may be absolute, or relative to the current <code>project.xml</code> file. For example, <code>&lt;extend&gt;${basedir}/../project.xml&lt;/extend&gt;</code>."
		},
		parent: {
			required: false,
			type: "Parent",
			description: "The location of the parent project, if one exists. Values from the parent project will be the default for this project if they are left unspecified. The location is given as a group ID, artifact ID and version."
		},
		groupId: {
			required: true,
			validation: /^\S*$/,
			message: "no whitespaces allowed in groupId.",
			type: "string",
			description: "A universally unique identifier for a project. It is normal to use a fully-qualified package name to distinguish it from other projects with a similar name (eg. <code>org.apache.maven</code>)."
		},
		artifactId: {
			required: true,
			validation: /^\S*$/,
			message: "no whitespaces allowed in artifactId.",
			type: "string",
			description: "The identifier for this artifact that is unique within the group given by the group ID. An artifact is something that is either produced or used by a project. Examples of artifacts produced by Maven for a project include: JARs, source and binary distributions, and WARs."
		},
		id: {
			required: true,
			type: "string",
			description: "<b>Deprecated</b>. When used, this sets both the <code>groupId</code> and <code>artifactId</code> elements if they were previously empty."
		},
		currentVersion: {
			required: true,
			type: "string",
			description: "The current version of the artifact produced by this project."
		},
		version: {
			required: true,
			validation: /^\S*$/,
			message: "no whitespaces allowed in version.",
			type: "string",
			description: "The current version of the artifact produced by this project."
		},
		versions: {
			required: false,
			type: "Version[]",
			description: "Contains information on previous versions of the project."
		},
		packaging: {
			required: false,
			type: "string",
			description: "The type of artifact this project produces, for example <code>jar</code> <code>war</code> <code>ear</code> <code>pom</code>. Plugins can create their own packaging, and therefore their own packaging types, so this list does not contain all possible types."
		},
		name: {
			required: true,
			type: "string",
			description: "The full name of the project."
		},
		shortDescription: {
			required: false,
			type: "string",
			description: "A short description of the project. The short description should be limited to a single line."
		},
		description: {
			required: false,
			type: "string",
			description: "A detailed description of the project, used by Maven whenever it needs to describe the project, such as on the web site. While this element can be specified as CDATA to enable the use of HTML tags within the description, it is discouraged to allow plain text representation. If you need to modify the index page of the generated web site, you are able to specify your own instead of adjusting this text."
		},
		url: {
			required: false,
			type: "string",
			description: "The URL to the project's homepage."
		},
		siteAddress: {
			required: false,
			type: "string",
			description: "The hostname of the web server that hosts the project's web site. This is used when the web site is deployed."
		},
		siteDirectory: {
			required: false,
			type: "string",
			description: "The directory on the web server where the public web site for this project resides. This is used when the web site is deployed."
		},
		inceptionYear: {
			required: true,
			type: "string",
			description: "The year of the project's inception, specified with 4 digits. This value is used when generating copyright notices as well as being informational."
		},
		logo: {
			required: false,
			type: "string",
			description: "The URL of the project's logo image. This can be an URL relative to the base directory of the generated web site, (e.g., <code>/images/project-logo.png</code>) or an absolute URL (e.g., <code>http://my.corp/project-logo.png</code>). This is used when generating the project documentation."
		},
		organization: {
			required: false,
			type: "Organization",
			description: "This element describes various attributes of the organization to which the project belongs. These attributes are utilized when documentation is created (for copyright notices and links)."
		},
		licenses: {
			required: false,
			type: "License[]",
			description: "This element describes all of the licenses for this project. Each license is described by a <code>license</code> element, which is then described by additional elements. Projects should only list the license(s) that applies to the project and not the licenses that apply to dependencies. If multiple licenses are listed, it is assumed that the user can select any of them, not that they must accept all."
		},
		mailingLists: {
			required: false,
			type: "MailingList[]",
			description: "Contains information about a project's mailing lists."
		},
		developers: {
			required: false,
			type: "Developer[]",
			description: "Describes the committers of a project."
		},
		contributors: {
			required: false,
			type: "Contributor[]",
			description: "Describes the contributors to a project that are not yet committers."
		},
		issueTrackingUrl: {
			required: false,
			type: "string",
			description: "The URL of the project's issue tracking system."
		},
		issueManagement: {
			required: false,
			type: "IssueManagement",
			description: "The project's issue management system information."
		},
		branches: {
			required: false,
			type: "Branch[]",
			description: "Contains information on SCM branches of the project."
		},
		repository: {
			required: false,
			type: "Repository",
			description: "Specification for the SCM used by the project, such as CVS, Subversion, etc."
		},
		scm: {
			required: false,
			type: "Scm",
			description: "Specification for the SCM used by the project, such as CVS, Subversion, etc."
		},
		gumpRepositoryId: {
			required: false,
			type: "string",
			description: "This is the repository identifier in Gump that this project is part of."
		},
		ciManagement: {
			required: false,
			type: "CiManagement",
			description: "The project's continuous integration information."
		},
		distributionSite: {
			required: false,
			type: "string",
			description: "The server where the final distributions will be published. This is used when the distributions are deployed. If this isn't defined, the central repository is used instead as determined by <code>maven.repo.central</code> and <code>maven.repo.central.directory</code>."
		},
		distributionDirectory: {
			required: false,
			type: "string",
			description: "The directory on the web server where the final distributions will be published. This is used when the distributions are deployed."
		},
		packageGroups: {
			required: false,
			type: "PackageGroup[]",
			description: "Package groups required for complete javadocs."
		},
		reports: {
			required: false,
			type: "string[]",
			description: "This element includes the specification of reports to be included in a Maven-generated site. These reports will be run when a user executes <code>maven site</code>. All of the reports will be included in the navigation bar for browsing in the order they are specified."
		},
		properties: {
			required: false,
			type: "Property[]",
			description: "Project properties that will be used by various plugins. The format is <code>&lt;name&gt;value&lt;/name&gt;</code>."
		},
		packageName: {
			required: false,
			type: "string",
			description: "The Java package name of the project. This value is used when generating JavaDoc."
		},
		prerequisites: {
			required: false,
			type: "Prerequisites",
			description: "Describes the prerequisites in the build environment for this project."
		},
		build: {
			required: true,
			type: "Build",
			description: "Information required to build the project."
		},
		profiles: {
			required: false,
			type: "Profile[]",
			description: "A listing of project-local build profiles which will modify the build process when activated."
		},
		distributionManagement: {
			required: false,
			type: "DistributionManagement",
			description: "Distribution information for a project that enables deployment of the site and artifacts to remote web servers and repositories respectively."
		},
		modules: {
			required: false,
			type: "string[]",
			description: "The modules (sometimes called subprojects) to build as a part of this project. Each module listed is a relative path to the directory containing the module."
		},
		repositories: {
			required: false,
			type: "Repository[]",
			description: "The lists of the remote repositories for discovering dependencies and extensions."
		},
		pluginRepositories: {
			required: false,
			type: "Repository[]",
			description: "The lists of the remote repositories for discovering plugins for builds and reports."
		},
		dependencies: {
			required: false,
			type: "Dependency[]",
			description: "This element describes all of the dependencies associated with a project. These dependencies are used to construct a classpath for your project during the build process. They are automatically downloaded from the repositories defined in this project. See <a href='http://maven.apache.org/guides/introduction/introduction-to-dependency-mechanism.html'>the dependency mechanism</a> for more information."
		},
		reports: {
			required: false,
			type: "string",
			description: "<b>Deprecated</b>. Now ignored by Maven."
		},
		reporting: {
			required: false,
			type: "Reporting",
			description: "This element includes the specification of report plugins to use to generate the reports on the Maven-generated site. These reports will be run when a user executes <code>mvn site</code>. All of the reports will be included in the navigation bar for browsing."
		},
		dependencyManagement: {
			required: false,
			type: "DependencyManagement",
			description: "Default dependency information for projects that inherit from this one. The dependencies in this section are not immediately resolved. Instead, when a POM derived from this one declares a dependency described by a matching groupId and artifactId, the version and other values from this section are used for that dependency if they were not already specified."
		},
		properties: {
			required: false,
			type: "Property[]",
			description: "Properties that can be used throughout the POM as a substitution, and are used as filters in resources if enabled. The format is <code>&lt;name&gt;value&lt;/name&gt;</code>."
		}
	}
});
jsBind.addType("ModelBase",{
	properties: {
		distributionManagement: {
			required: false,
			type: "DistributionManagement",
			description: "Distribution information for a project that enables deployment of the site and artifacts to remote web servers and repositories respectively."
		},
		modules: {
			required: false,
			type: "string[]",
			description: "The modules (sometimes called subprojects) to build as a part of this project. Each module listed is a relative path to the directory containing the module."
		},
		repositories: {
			required: false,
			type: "Repository[]",
			description: "The lists of the remote repositories for discovering dependencies and extensions."
		},
		pluginRepositories: {
			required: false,
			type: "Repository[]",
			description: "The lists of the remote repositories for discovering plugins for builds and reports."
		},
		dependencies: {
			required: false,
			type: "Dependency[]",
			description: "This element describes all of the dependencies associated with a project. These dependencies are used to construct a classpath for your project during the build process. They are automatically downloaded from the repositories defined in this project. See <a href='http://maven.apache.org/guides/introduction/introduction-to-dependency-mechanism.html'>the dependency mechanism</a> for more information."
		},
		reports: {
			required: false,
			type: "string",
			description: "<b>Deprecated</b>. Now ignored by Maven."
		},
		reporting: {
			required: false,
			type: "Reporting",
			description: "This element includes the specification of report plugins to use to generate the reports on the Maven-generated site. These reports will be run when a user executes <code>mvn site</code>. All of the reports will be included in the navigation bar for browsing."
		},
		dependencyManagement: {
			required: false,
			type: "DependencyManagement",
			description: "Default dependency information for projects that inherit from this one. The dependencies in this section are not immediately resolved. Instead, when a POM derived from this one declares a dependency described by a matching groupId and artifactId, the version and other values from this section are used for that dependency if they were not already specified."
		},
		properties: {
			required: false,
			type: "Property[]",
			description: "Properties that can be used throughout the POM as a substitution, and are used as filters in resources if enabled. The format is <code>&lt;name&gt;value&lt;/name&gt;</code>."
		}
	}
});
jsBind.addType("Branch",{
	properties: {
		tag: {
			required: true,
			type: "string",
			description: "The branch tag in the version control system (e.g. cvs) used by the project for the source code associated with this branch of the project."
		}
	}
});
jsBind.addType("PluginContainer",{
	properties: {
		plugins: {
			required: false,
			type: "Plugin[]",
			description: "The list of plugins to use."
		}
	}
});
jsBind.addType("PluginConfiguration",{
	properties: {
		plugins: {
			required: false,
			type: "Plugin[]",
			description: "The list of plugins to use."
		},
		pluginManagement: {
			required: false,
			type: "PluginManagement",
			description: "Default plugin information to be made available for reference by projects derived from this one. This plugin configuration will not be resolved or bound to the lifecycle unless referenced. Any local configuration for a given plugin will override the plugin's entire definition here."
		}
	}
});
jsBind.addType("BuildBase",{
	properties: {
		plugins: {
			required: false,
			type: "Plugin[]",
			description: "The list of plugins to use."
		},
		pluginManagement: {
			required: false,
			type: "PluginManagement",
			description: "Default plugin information to be made available for reference by projects derived from this one. This plugin configuration will not be resolved or bound to the lifecycle unless referenced. Any local configuration for a given plugin will override the plugin's entire definition here."
		},
		defaultGoal: {
			required: false,
			type: "string",
			description: "The default goal (or phase in Maven 2) to execute when none is specified for the project."
		},
		resources: {
			required: false,
			type: "Resource[]",
			description: "This element describes all of the classpath resources such as properties files associated with a project. These resources are often included in the final package."
		},
		testResources: {
			required: false,
			type: "Resource[]",
			description: "This element describes all of the classpath resources such as properties files associated with a project's unit tests."
		},
		directory: {
			required: false,
			type: "string",
			description: "The directory where all files generated by the build are placed."
		},
		finalName: {
			required: false,
			type: "string",
			description: "The filename (excluding the extension, and with no path information) that the produced artifact will be called. The default value is <code>${artifactId}-${version}</code>."
		},
		filters: {
			required: false,
			type: "string[]",
			description: "The list of filter properties files that are used when filtering is enabled."
		}
	}
});
jsBind.addType("Build",{
	properties: {
		plugins: {
			required: false,
			type: "Plugin[]",
			description: "The list of plugins to use."
		},
		pluginManagement: {
			required: false,
			type: "PluginManagement",
			description: "Default plugin information to be made available for reference by projects derived from this one. This plugin configuration will not be resolved or bound to the lifecycle unless referenced. Any local configuration for a given plugin will override the plugin's entire definition here."
		},
		defaultGoal: {
			required: false,
			type: "string",
			description: "The default goal (or phase in Maven 2) to execute when none is specified for the project."
		},
		resources: {
			required: false,
			type: "Resource[]",
			description: "This element describes all of the classpath resources such as properties files associated with a project. These resources are often included in the final package."
		},
		testResources: {
			required: false,
			type: "Resource[]",
			description: "This element describes all of the classpath resources such as properties files associated with a project's unit tests."
		},
		directory: {
			required: false,
			type: "string",
			description: "The directory where all files generated by the build are placed."
		},
		finalName: {
			required: false,
			type: "string",
			description: "The filename (excluding the extension, and with no path information) that the produced artifact will be called. The default value is <code>${artifactId}-${version}</code>."
		},
		filters: {
			required: false,
			type: "string[]",
			description: "The list of filter properties files that are used when filtering is enabled."
		},
		nagEmailAddress: {
			required: false,
			type: "string",
			description: "An address to which notifications regarding the status of builds for this project can be sent. This is intended for use by tools which do unattended builds, for example those providing for continuous integration."
		},
		sourceDirectory: {
			required: true,
			type: "string",
			description: "This element specifies a directory containing the source of the project. The generated build system will compile the source in this directory when the project is built. The path given is relative to the project descriptor."
		},
		scriptSourceDirectory: {
			required: true,
			type: "string",
			description: "This element specifies a directory containing the script sources of the project. This directory is meant to be different from the sourceDirectory, in that its contents will be copied to the output directory in most cases (since scripts are interpreted rather than compiled)."
		},
		unitTestSourceDirectory: {
			required: true,
			type: "string",
			description: "This element specifies a directory containing the unit test source of the project. The generated build system will compile these directories when the project is being tested. The path given is relative to the project descriptor."
		},
		testSourceDirectory: {
			required: true,
			type: "string",
			description: "This element specifies a directory containing the unit test source of the project. The generated build system will compile these directories when the project is being tested. The path given is relative to the project descriptor."
		},
		aspectSourceDirectory: {
			required: false,
			type: "string",
			description: "This element specifies a directory containing Aspect sources of the project. The generated build system will compile the Aspects in this directory when the project is built if Aspects have been enabled. The path given is relative to the project descriptor."
		},
		integrationUnitTestSourceDirectory: {
			required: false,
			type: "string",
			description: "This element is <b>deprecated</b> and should no longer be used. Initially it was used by the first Cactus plugin. Now the location of the Cactus test sources is defined through a plugin property. See the Cactus plugin <a href='http://jakarta.apache.org/cactus/integration/maven/properties.html'>properties</a> page."
		},
		sourceModifications: {
			required: true,
			type: "SourceModification[]",
			description: "This element describes all of the sourceModifications associated with a project. These modifications are used to exclude or include various source depending on the environment the build is running in."
		},
		unitTest: {
			required: true,
			type: "UnitTest",
			description: "This element specifies unit tests associated with the project."
		},
		outputDirectory: {
			required: false,
			type: "string",
			description: "The directory where compiled application classes are placed."
		},
		testOutputDirectory: {
			required: false,
			type: "string",
			description: "The directory where compiled test classes are placed."
		},
		extensions: {
			required: false,
			type: "Extension[]",
			description: "A set of build extensions to use from this project."
		}
	}
});
jsBind.addType("CiManagement",{
	properties: {
		system: {
			required: false,
			type: "string",
			description: "The name of the continuous integration system, e.g. <code>continuum</code>."
		},
		url: {
			required: false,
			type: "string",
			description: "URL for the continuous integration system used by the project if it has a web interface."
		},
		notifiers: {
			required: false,
			type: "Notifier[]",
			description: "Configuration for notifying developers/users when a build is unsuccessful, including user information and notification mode."
		}
	}
});
jsBind.addType("Notifier",{
	properties: {
		type: {
			required: false,
			type: "string",
			description: "The mechanism used to deliver notifications."
		},
		sendOnError: {
			required: false,
			type: "boolean",
			description: "Whether to send notifications on error."
		},
		sendOnFailure: {
			required: false,
			type: "boolean",
			description: "Whether to send notifications on failure."
		},
		sendOnSuccess: {
			required: false,
			type: "boolean",
			description: "Whether to send notifications on success."
		},
		sendOnWarning: {
			required: false,
			type: "boolean",
			description: "Whether to send notifications on warning."
		},
		address: {
			required: false,
			type: "string",
			description: "<b>Deprecated</b>. Where to send the notification to - eg email address."
		},
		configuration: {
			required: false,
			type: "Property[]",
			description: "Extended configuration specific to this notifier goes here."
		}
	}
});
jsBind.addType("Contributor",{
	properties: {
		name: {
			required: false,
			type: "string",
			description: "The full name of the contributor."
		},
		email: {
			required: false,
			type: "string",
			description: "The email address of the contributor."
		},
		url: {
			required: false,
			type: "string",
			description: "The URL for the homepage of the contributor."
		},
		organization: {
			required: false,
			type: "string",
			description: "The organization to which the contributor belongs."
		},
		organizationUrl: {
			required: false,
			type: "string",
			description: "The URL of the organization."
		},
		roles: {
			required: false,
			type: "string[]",
			description: "The roles the contributor plays in the project. Each role is described by a <code>role</code> element, the body of which is a role name. This can also be used to describe the contribution."
		},
		timezone: {
			required: false,
			type: "string",
			description: "The timezone the contributor is in. This is a number in the range -11 to 12."
		},
		properties: {
			required: false,
			type: "Property[]",
			description: "Properties about the contributor, such as an instant messenger handle."
		}
	}
});
jsBind.addType("Dependency",{
	properties: {
		id: {
			required: true,
			type: "string",
			description: "<b>Deprecated</b>. Please use <code>groupId</code> and <code>artifactId</code> together instead."
		},
		groupId: {
			required: true,
			type: "string",
			description: "The project group that produced the dependency, e.g. <code>org.apache.maven</code>."
		},
		artifactId: {
			required: true,
			type: "string",
			description: "The unique id for an artifact produced by the project group, e.g. <code>maven-artifact</code>."
		},
		version: {
			required: false,
			type: "string",
			description: "The version of the dependency, e.g. <code>3.2.1</code>. In Maven 2, this can also be specified as a range of versions."
		},
		url: {
			required: false,
			type: "string",
			description: "This url will be provided to the user if the jar file cannot be downloaded from the central repository."
		},
		jar: {
			required: false,
			type: "string",
			description: "Literal name of the artifact in the repository. Used to override the calculated artifact name."
		},
		type: {
			required: false,
			type: "string",
			description: "The type of dependency. This defaults to <code>jar</code>. While it usually represents the extension on the filename of the dependency, that is not always the case. Some examples are <code>jar</code>, <code>war</code>, and <code>plugin</code>. A dependency of type <code>plugin</code> is loaded as a Maven plugin and not added to the project build classpath."
		},
		type: {
			required: false,
			type: "string",
			description: "The type of dependency. This defaults to <code>jar</code>. While it usually represents the extension on the filename of the dependency, that is not always the case. A type can be mapped to a different extension and a classifier. The type often correspongs to the packaging used, though this is also not always the case. Some examples are <code>jar</code>, <code>war</code>, <code>ejb-client</code> and <code>test-jar</code>. New types can be defined by plugins that set <code>extensions</code> to <code>true</code>, so this is not a complete list."
		},
		classifier: {
			required: false,
			type: "string",
			description: "The classifier of the dependency. This allows distinguishing two artifacts that belong to the same POM but were built differently, and is appended to the filename after the version. For example, <code>jdk14</code> and <code>jdk15</code>."
		},
		properties: {
			required: false,
			type: "Property[]",
			description: "Properties about the dependency. Various plugins allow you to mark dependencies with properties. For example the war plugin looks for a <code>war.bundle</code> property, and if found will include the dependency in <code>WEB-INF/lib</code>."
		},
		scope: {
			required: false,
			type: "Scope",
			description: "The scope of the dependency - <code>compile</code>, <code>runtime</code>, <code>test</code>, <code>system</code>, and <code>provided</code>. Used to calculate the various classpaths used for compilation, testing, and so on. It also assists in determining which artifacts to include in a distribution of this project. For more information, see <a href='http://maven.apache.org/guides/introduction/introduction-to-dependency-mechanism.html'>the dependency mechanism</a>."
		},
		systemPath: {
			required: false,
			type: "string",
			description: "FOR SYSTEM SCOPE ONLY. Note that use of this property is <b>discouraged</b> and may be replaced in later versions. This specifies the path on the filesystem for this dependency. Requires an absolute path for the value, not relative. Use a property that gives the machine specific absolute path, e.g. <code>${java.home}</code>."
		},
		exclusions: {
			required: false,
			type: "Exclusion[]",
			description: "Lists a set of artifacts that should be excluded from this dependency's artifact list when it comes to calculating transitive dependencies."
		},
		optional: {
			required: false,
			type: "boolean",
			description: "Indicates the dependency is optional for use of this library. While the version of the dependency will be taken into account for dependency calculation if the library is used elsewhere, it will not be passed on transitively."
		}
	}
});
jsBind.addType("Developer",{
	properties: {
		name: {
			required: false,
			type: "string",
			description: "The full name of the contributor."
		},
		email: {
			required: false,
			type: "string",
			description: "The email address of the contributor."
		},
		url: {
			required: false,
			type: "string",
			description: "The URL for the homepage of the contributor."
		},
		organization: {
			required: false,
			type: "string",
			description: "The organization to which the contributor belongs."
		},
		organizationUrl: {
			required: false,
			type: "string",
			description: "The URL of the organization."
		},
		roles: {
			required: false,
			type: "string[]",
			description: "The roles the contributor plays in the project. Each role is described by a <code>role</code> element, the body of which is a role name. This can also be used to describe the contribution."
		},
		timezone: {
			required: false,
			type: "string",
			description: "The timezone the contributor is in. This is a number in the range -11 to 12."
		},
		properties: {
			required: false,
			type: "Property[]",
			description: "Properties about the contributor, such as an instant messenger handle."
		},
		id: {
			required: false,
			type: "string",
			description: "The unique ID of the developer in the SCM."
		}
	}
});
jsBind.addType("Exclusion",{
	properties: {
		artifactId: {
			required: true,
			type: "string",
			description: "The artifact ID of the project to exclude."
		},
		groupId: {
			required: true,
			type: "string",
			description: "The group ID of the project to exclude."
		}
	}
});
jsBind.addType("IssueManagement",{
	properties: {
		system: {
			required: false,
			type: "string",
			description: "The name of the issue management system, e.g. Bugzilla"
		},
		url: {
			required: false,
			type: "string",
			description: "URL for the issue management system used by the project."
		}
	}
});
jsBind.addType("DistributionManagement",{
	properties: {
		repository: {
			required: false,
			type: "DeploymentRepository",
			description: "Information needed to deploy the artifacts generated by the project to a remote repository."
		},
		snapshotRepository: {
			required: false,
			type: "DeploymentRepository",
			description: "Where to deploy snapshots of artifacts to. If not given, it defaults to the <code>repository</code> element."
		},
		site: {
			required: false,
			type: "Site",
			description: "Information needed for deploying the web site of the project."
		},
		downloadUrl: {
			required: false,
			type: "string",
			description: "The URL of the project's download page. If not given users will be referred to the homepage given by <code>url</code>. This is given to assist in locating artifacts that are not in the repository due to licensing restrictions."
		},
		relocation: {
			required: false,
			type: "Relocation",
			description: "Relocation information of the artifact if it has been moved to a new group ID and/or artifact ID."
		},
		status: {
			required: false,
			type: "string",
			description: "Gives the status of this artifact in the remote repository. This must not be set in your local project, as it is updated by tools placing it in the reposiory. Valid values are: <code>none</code> (default), <code>converted</code> (repository manager converted this from an Maven 1 POM), <code>partner</code> (directly synced from a partner Maven 2 repository), <code>deployed</code> (was deployed from a Maven 2 instance), <code>verified</code> (has been hand verified as correct and final)."
		}
	}
});
jsBind.addType("License",{
	properties: {
		name: {
			required: false,
			type: "string",
			description: "The full legal name of the license."
		},
		url: {
			required: false,
			type: "string",
			description: "The official url for the license text."
		},
		distribution: {
			required: false,
			type: "string",
			description: "The primary method by which this project may be distributed. <dl> <dt>repo</dt> <dd>may be downloaded from the Maven repository</dd> <dt>manual</dt> <dd>user must manually download and install the dependency.</dd> </dl>"
		},
		comments: {
			required: false,
			type: "string",
			description: "Addendum information pertaining to this license."
		}
	}
});
jsBind.addType("MailingList",{
	properties: {
		name: {
			required: false,
			type: "string",
			description: "The name of the mailing list."
		},
		subscribe: {
			required: false,
			type: "string",
			description: "The email address or link that can be used to subscribe to the mailing list. If this is an email address, a <code>mailto:</code> link will automatically be created when the documentation is created."
		},
		unsubscribe: {
			required: false,
			type: "string",
			description: "The email address or link that can be used to unsubscribe to the mailing list. If this is an email address, a <code>mailto:</code> link will automatically be created when the documentation is created."
		},
		post: {
			required: false,
			type: "string",
			description: "The email address or link that can be used to post to the mailing list. If this is an email address, a <code>mailto:</code> link will automatically be created when the documentation is created."
		},
		archive: {
			required: false,
			type: "string",
			description: "The link to a URL where you can browse the mailing list archive."
		},
		otherArchives: {
			required: false,
			type: "string[]",
			description: "The link to alternate URLs where you can browse the list archive."
		}
	}
});
jsBind.addType("Organization",{
	properties: {
		name: {
			required: false,
			type: "string",
			description: "The full name of the organization."
		},
		url: {
			required: false,
			type: "string",
			description: "The URL to the organization's home page."
		},
		logo: {
			required: false,
			type: "string",
			description: "The URL to the organization's logo image. This can be an URL relative to the base directory of the generated web site, (e.g., <code>/images/org-logo.png</code>) or an absolute URL (e.g., <code>http://my.corp/logo.png</code>). This value is used when generating the project documentation."
		}
	}
});
jsBind.addType("PackageGroup",{
	properties: {
		title: {
			required: false,
			type: "string",
			description: "The title to use for the package group."
		},
		packages: {
			required: false,
			type: "string",
			description: "The packages in the group"
		}
	}
});
jsBind.addType("PatternSet",{
	properties: {
		includes: {
			required: false,
			type: "string[]",
			description: "A list of patterns to include, e.g. <code>**&#47;*.xml</code>."
		},
		excludes: {
			required: false,
			type: "string[]",
			description: "A list of patterns to exclude, e.g. <code>**&#47;*.xml</code>"
		}
	}
});
jsBind.addType("Parent",{
	properties: {
		artifactId: {
			required: true,
			type: "string",
			description: "The artifact id of the parent project to inherit from."
		},
		groupId: {
			required: true,
			type: "string",
			description: "The group id of the parent project to inherit from."
		},
		version: {
			required: false,
			type: "string",
			description: "The version of the parent project to inherit."
		},
		relativePath: {
			required: false,
			type: "string",
			description: "The relative path of the parent <code>pom.xml</code> file within the check out. The default value is <code>../pom.xml</code>. Maven looks for the parent pom first in the reactor of currently building projects, then in this location on the filesystem, then the local repository, and lastly in the remote repo. <code>relativePath</code> allows you to select a different location, for example when your structure is flat, or deeper without an intermediate parent pom. However, the group ID, artifact ID and version are still required, and must match the file in the location given or it will revert to the repository for the POM. This feature is only for enhancing the development in a local checkout of that project."
		}
	}
});
jsBind.addType("Repository",{
	properties: {
		connection: {
			required: false,
			type: "string",
			description: "The source control management system URL that describes the repository and how to connect to the repository. For more information, see the <a href='http://maven.apache.org/scm/scm-url-format.html'>URL format</a> and <a href='http://maven.apache.org/scm/scms-overview.html'>list of supported SCMs</a>. This connection is read-only."
		},
		developerConnection: {
			required: false,
			type: "string",
			description: "Just like <code>connection</code>, but for developers, i.e. this scm connection will not be read only."
		},
		url: {
			required: false,
			type: "string",
			description: "The URL to the project's browsable SCM repository, such as ViewVC or Fisheye."
		},
		id: {
			required: true,
			type: "string",
			description: "A unique identifier for a repository. This is used to match the repository to configuration in the <code>settings.xml</code> file, for example. Furthermore, the identifier is used during POM inheritance and profile injection to detect repositories that should be merged."
		},
		name: {
			required: false,
			type: "string",
			description: "Human readable name of the repository."
		},
		url: {
			required: true,
			type: "string",
			description: "The url of the repository, in the form <code>protocol://hostname/path</code>."
		},
		layout: {
			required: false,
			type: "string",
			description: "The type of layout this repository uses for locating and storing artifacts - can be <code>legacy</code> or <code>default</code>."
		},
		releases: {
			required: false,
			type: "RepositoryPolicy",
			description: "How to handle downloading of releases from this repository."
		},
		snapshots: {
			required: false,
			type: "RepositoryPolicy",
			description: "How to handle downloading of snapshots from this repository."
		}
	}
});
jsBind.addType("Scm",{
	properties: {
		connection: {
			required: false,
			type: "string",
			description: "The source control management system URL that describes the repository and how to connect to the repository. For more information, see the <a href='http://maven.apache.org/scm/scm-url-format.html'>URL format</a> and <a href='http://maven.apache.org/scm/scms-overview.html'>list of supported SCMs</a>. This connection is read-only."
		},
		developerConnection: {
			required: false,
			type: "string",
			description: "Just like <code>connection</code>, but for developers, i.e. this scm connection will not be read only."
		},
		tag: {
			required: false,
			type: "string",
			description: "The tag of current code. By default, it's set to HEAD during development."
		},
		url: {
			required: false,
			type: "string",
			description: "The URL to the project's browsable SCM repository, such as ViewVC or Fisheye."
		}
	}
});
jsBind.addType("FileSet",{
	properties: {
		includes: {
			required: false,
			type: "string[]",
			description: "A list of patterns to include, e.g. <code>**&#47;*.xml</code>."
		},
		excludes: {
			required: false,
			type: "string[]",
			description: "A list of patterns to exclude, e.g. <code>**&#47;*.xml</code>"
		},
		directory: {
			required: false,
			type: "string",
			description: "Describe the directory where the resources are stored. The path is relative to the POM."
		}
	}
});
jsBind.addType("Resource",{
	properties: {
		includes: {
			required: false,
			type: "string[]",
			description: "A list of patterns to include, e.g. <code>**&#47;*.xml</code>."
		},
		excludes: {
			required: false,
			type: "string[]",
			description: "A list of patterns to exclude, e.g. <code>**&#47;*.xml</code>"
		},
		directory: {
			required: false,
			type: "string",
			description: "Describe the directory where the resources are stored. The path is relative to the POM."
		},
		targetPath: {
			required: false,
			type: "string",
			description: "Describe the resource target path. The path is relative to the target/classes directory (i.e. <code>${project.build.outputDirectory}</code>). For example, if you want that resource to appear in a specific package (<code>org.apache.maven.messages</code>), you must specify this element with this value: <code>org/apache/maven/messages</code>. This is not required if you simply put the resources in that directory structure at the source, however."
		},
		filtering: {
			required: false,
			type: "boolean",
			description: "Whether resources are filtered to replace tokens with parameterised values or not. The values are taken from the <code>properties</code> element and from the properties in the files listed in the <code>filters</code> element."
		},
		mergeId: {
			required: false,
			type: "string",
			description: "FOR INTERNAL USE ONLY. This is a unique identifier assigned to each resource to allow Maven to merge changes to this resource that take place during the execution of a plugin. This field must be managed by the generated parser and formatter classes in order to allow it to survive model interpolation."
		}
	}
});
jsBind.addType("SourceModification",{
	properties: {
		includes: {
			required: false,
			type: "string[]",
			description: "A list of patterns to include, e.g. <code>**&#47;*.xml</code>."
		},
		excludes: {
			required: false,
			type: "string[]",
			description: "A list of patterns to exclude, e.g. <code>**&#47;*.xml</code>"
		},
		directory: {
			required: false,
			type: "string",
			description: "Describe the directory where the resources are stored. The path is relative to the POM."
		},
		className: {
			required: false,
			type: "string",
			description: "If the class with this name can <b>not</b> be loaded, then the includes and excludes specified below will be applied to the contents of the <code>sourceDirectory</code>."
		},
		property: {
			required: false,
			type: "string",
			description: "If the property with this name is <b>not</b> set, then the includes and excludes specified below will be applied to the contents of the <code>sourceDirectory</code>."
		}
	}
});
jsBind.addType("UnitTest",{
	properties: {
		includes: {
			required: false,
			type: "string[]",
			description: "A list of patterns to include, e.g. <code>**&#47;*.xml</code>."
		},
		excludes: {
			required: false,
			type: "string[]",
			description: "A list of patterns to exclude, e.g. <code>**&#47;*.xml</code>"
		},
		resources: {
			required: false,
			type: "Resource[]",
			description: "The classpath resources to use when executing the unit tests."
		}
	}
});
jsBind.addType("Version",{
	properties: {
		name: {
			required: false,
			type: "string",
			description: "The external version number under which this release was distributed. Examples include: <code>1.0</code>, <code>1.1-alpha1</code>, <code>1.2-beta</code>, <code>1.3.2</code> etc."
		},
		tag: {
			required: false,
			type: "string",
			description: "The name given in the SCM (e.g. CVS) used by the project for the source code associated with this version of the project."
		},
		id: {
			required: false,
			type: "string",
			description: "A unique identifier for a version. This is usually identical to the name."
		}
	}
});
jsBind.addType("RepositoryBase",{
	properties: {
		id: {
			required: true,
			type: "string",
			description: "A unique identifier for a repository. This is used to match the repository to configuration in the <code>settings.xml</code> file, for example. Furthermore, the identifier is used during POM inheritance and profile injection to detect repositories that should be merged."
		},
		name: {
			required: false,
			type: "string",
			description: "Human readable name of the repository."
		},
		url: {
			required: true,
			type: "string",
			description: "The url of the repository, in the form <code>protocol://hostname/path</code>."
		},
		layout: {
			required: false,
			type: "string",
			description: "The type of layout this repository uses for locating and storing artifacts - can be <code>legacy</code> or <code>default</code>."
		}
	}
});
jsBind.addType("Repository",{
	properties: {
		connection: {
			required: false,
			type: "string",
			description: "The source control management system URL that describes the repository and how to connect to the repository. For more information, see the <a href='http://maven.apache.org/scm/scm-url-format.html'>URL format</a> and <a href='http://maven.apache.org/scm/scms-overview.html'>list of supported SCMs</a>. This connection is read-only."
		},
		developerConnection: {
			required: false,
			type: "string",
			description: "Just like <code>connection</code>, but for developers, i.e. this scm connection will not be read only."
		},
		url: {
			required: false,
			type: "string",
			description: "The URL to the project's browsable SCM repository, such as ViewVC or Fisheye."
		},
		id: {
			required: true,
			type: "string",
			description: "A unique identifier for a repository. This is used to match the repository to configuration in the <code>settings.xml</code> file, for example. Furthermore, the identifier is used during POM inheritance and profile injection to detect repositories that should be merged."
		},
		name: {
			required: false,
			type: "string",
			description: "Human readable name of the repository."
		},
		url: {
			required: true,
			type: "string",
			description: "The url of the repository, in the form <code>protocol://hostname/path</code>."
		},
		layout: {
			required: false,
			type: "string",
			description: "The type of layout this repository uses for locating and storing artifacts - can be <code>legacy</code> or <code>default</code>."
		},
		releases: {
			required: false,
			type: "RepositoryPolicy",
			description: "How to handle downloading of releases from this repository."
		},
		snapshots: {
			required: false,
			type: "RepositoryPolicy",
			description: "How to handle downloading of snapshots from this repository."
		}
	}
});
jsBind.addType("DeploymentRepository",{
	properties: {
		id: {
			required: true,
			type: "string",
			description: "A unique identifier for a repository. This is used to match the repository to configuration in the <code>settings.xml</code> file, for example. Furthermore, the identifier is used during POM inheritance and profile injection to detect repositories that should be merged."
		},
		name: {
			required: false,
			type: "string",
			description: "Human readable name of the repository."
		},
		url: {
			required: true,
			type: "string",
			description: "The url of the repository, in the form <code>protocol://hostname/path</code>."
		},
		layout: {
			required: false,
			type: "string",
			description: "The type of layout this repository uses for locating and storing artifacts - can be <code>legacy</code> or <code>default</code>."
		},
		uniqueVersion: {
			required: false,
			type: "boolean",
			description: "Whether to assign snapshots a unique version comprised of the timestamp and build number, or to use the same version each time"
		}
	}
});
jsBind.addType("RepositoryPolicy",{
	properties: {
		enabled: {
			required: false,
			type: "boolean",
			description: "Whether to use this repository for downloading this type of artifact."
		},
		updatePolicy: {
			required: false,
			type: "string",
			description: "The frequency for downloading updates - can be <code>always,</code> <code>daily</code> (default), <code>interval:XXX</code> (in minutes) or <code>never</code> (only if it doesn't exist locally)."
		},
		checksumPolicy: {
			required: false,
			type: "string",
			description: "What to do when verification of an artifact checksum fails. Valid values are <code>ignore</code> , <code>fail</code> or <code>warn</code> (the default)."
		}
	}
});
jsBind.addType("Site",{
	properties: {
		id: {
			required: false,
			type: "string",
			description: "A unique identifier for a deployment location. This is used to match the site to configuration in the <code>settings.xml</code> file, for example."
		},
		name: {
			required: false,
			type: "string",
			description: "Human readable name of the deployment location."
		},
		url: {
			required: false,
			type: "string",
			description: "The url of the location where website is deployed, in the form <code>protocol://hostname/path</code>."
		}
	}
});
jsBind.addType("ConfigurationContainer",{
	properties: {
		inherited: {
			required: false,
			type: "string",
			description: "Whether any configuration should be propagated to child POMs."
		},
		configuration: {
			required: false,
			type: "string",
			description: "The configuration as DOM object."
		}
	}
});
jsBind.addType("Plugin",{
	properties: {
		inherited: {
			required: false,
			type: "string",
			description: "Whether any configuration should be propagated to child POMs."
		},
		configuration: {
			required: false,
			type: "string",
			description: "The configuration as DOM object."
		},
		groupId: {
			required: true,
			type: "string",
			description: "The group ID of the plugin in the repository."
		},
		artifactId: {
			required: true,
			type: "string",
			description: "The artifact ID of the plugin in the repository."
		},
		version: {
			required: false,
			type: "string",
			description: "The version (or valid range of versions) of the plugin to be used."
		},
		extensions: {
			required: false,
			type: "boolean",
			description: "Whether to load Maven extensions (such as packaging and type handlers) from this plugin. For performance reasons, this should only be enabled when necessary."
		},
		executions: {
			required: false,
			type: "PluginExecution[]",
			description: "Multiple specifications of a set of goals to execute during the build lifecycle, each having (possibly) a different configuration."
		},
		dependencies: {
			required: false,
			type: "Dependency[]",
			description: "Additional dependencies that this project needs to introduce to the plugin's classloader."
		},
		goals: {
			required: false,
			type: "string",
			description: "<b>Deprecated</b>. Unused by Maven."
		}
	}
});
jsBind.addType("PluginExecution",{
	properties: {
		inherited: {
			required: false,
			type: "string",
			description: "Whether any configuration should be propagated to child POMs."
		},
		configuration: {
			required: false,
			type: "string",
			description: "The configuration as DOM object."
		},
		id: {
			required: true,
			type: "string",
			description: "The identifier of this execution for labelling the goals during the build, and for matching executions to merge during inheritance and profile injection."
		},
		phase: {
			required: false,
			type: "string",
			description: "The build lifecycle phase to bind the goals in this execution to. If omitted, the goals will be bound to the default phase specified in their metadata."
		},
		goals: {
			required: false,
			type: "string[]",
			description: "The goals to execute with the given configuration."
		}
	}
});
jsBind.addType("DependencyManagement",{
	properties: {
		dependencies: {
			required: false,
			type: "Dependency[]",
			description: "The dependencies specified here are not used until they are referenced in a POM within the group. This allows the specification of a 'standard' version for a particular dependency."
		}
	}
});
jsBind.addType("PluginManagement",{
	properties: {
		plugins: {
			required: false,
			type: "Plugin[]",
			description: "The list of plugins to use."
		}
	}
});
jsBind.addType("Reporting",{
	properties: {
		excludeDefaultsValue: {
			required: false,
			type: "boolean",
			description: "If true, then the default reports are not included in the site generation. This includes the reports in the 'Project Info' menu."
		},
		outputDirectory: {
			required: false,
			type: "string",
			description: "Where to store all of the generated reports. The default is <code>${project.build.directory}/site</code> ."
		},
		plugins: {
			required: false,
			type: "ReportPlugin[]",
			description: "The reporting plugins to use and their configuration."
		}
	}
});
jsBind.addType("Profile",{
	properties: {
		distributionManagement: {
			required: false,
			type: "DistributionManagement",
			description: "Distribution information for a project that enables deployment of the site and artifacts to remote web servers and repositories respectively."
		},
		modules: {
			required: false,
			type: "string[]",
			description: "The modules (sometimes called subprojects) to build as a part of this project. Each module listed is a relative path to the directory containing the module."
		},
		repositories: {
			required: false,
			type: "Repository[]",
			description: "The lists of the remote repositories for discovering dependencies and extensions."
		},
		pluginRepositories: {
			required: false,
			type: "Repository[]",
			description: "The lists of the remote repositories for discovering plugins for builds and reports."
		},
		dependencies: {
			required: false,
			type: "Dependency[]",
			description: "This element describes all of the dependencies associated with a project. These dependencies are used to construct a classpath for your project during the build process. They are automatically downloaded from the repositories defined in this project. See <a href='http://maven.apache.org/guides/introduction/introduction-to-dependency-mechanism.html'>the dependency mechanism</a> for more information."
		},
		reports: {
			required: false,
			type: "string",
			description: "<b>Deprecated</b>. Now ignored by Maven."
		},
		reporting: {
			required: false,
			type: "Reporting",
			description: "This element includes the specification of report plugins to use to generate the reports on the Maven-generated site. These reports will be run when a user executes <code>mvn site</code>. All of the reports will be included in the navigation bar for browsing."
		},
		dependencyManagement: {
			required: false,
			type: "DependencyManagement",
			description: "Default dependency information for projects that inherit from this one. The dependencies in this section are not immediately resolved. Instead, when a POM derived from this one declares a dependency described by a matching groupId and artifactId, the version and other values from this section are used for that dependency if they were not already specified."
		},
		properties: {
			required: false,
			type: "Property[]",
			description: "Properties that can be used throughout the POM as a substitution, and are used as filters in resources if enabled. The format is <code>&lt;name&gt;value&lt;/name&gt;</code>."
		},
		id: {
			required: true,
			type: "string",
			description: "The identifier of this build profile. This is used for command line activation, and identifies profiles to be merged."
		},
		activation: {
			required: false,
			type: "Activation",
			description: "The conditional logic which will automatically trigger the inclusion of this profile."
		},
		build: {
			required: true,
			type: "BuildBase",
			description: "Information required to build the project."
		}
	}
});
jsBind.addType("Activation",{
	properties: {
		activeByDefault: {
			required: false,
			type: "boolean",
			description: "If set to true, this profile will be active unless another profile in this pom is activated using the command line -P option or by one of that profile's activators."
		},
		jdk: {
			required: false,
			type: "string",
			description: "Specifies that this profile will be activated when a matching JDK is detected. For example, <code>1.4</code> only activates on JDKs versioned 1.4, while <code>!1.4</code> matches any JDK that is not version 1.4."
		},
		os: {
			required: false,
			type: "ActivationOS",
			description: "Specifies that this profile will be activated when matching operating system attributes are detected."
		},
		property: {
			required: false,
			type: "ActivationProperty",
			description: "Specifies that this profile will be activated when this system property is specified."
		},
		file: {
			required: false,
			type: "ActivationFile",
			description: "Specifies that this profile will be activated based on existence of a file."
		}
	}
});
jsBind.addType("ActivationProperty",{
	properties: {
		name: {
			required: true,
			type: "string",
			description: "The name of the property to be used to activate a profile."
		},
		value: {
			required: false,
			type: "string",
			description: "The value of the property required to activate a profile."
		}
	}
});
jsBind.addType("ActivationOS",{
	properties: {
		name: {
			required: false,
			type: "string",
			description: "The name of the operating system to be used to activate the profile. This must be an exact match of the <code>${os.name}</code> Java property, such as <code>Windows XP</code>."
		},
		family: {
			required: false,
			type: "string",
			description: "The general family of the OS to be used to activate the profile, such as <code>windows</code> or <code>unix</code>."
		},
		arch: {
			required: false,
			type: "string",
			description: "The architecture of the operating system to be used to activate the profile."
		},
		version: {
			required: false,
			type: "string",
			description: "The version of the operating system to be used to activate the profile."
		}
	}
});
jsBind.addType("ActivationFile",{
	properties: {
		missing: {
			required: false,
			type: "string",
			description: "The name of the file that must be missing to activate the profile."
		},
		exists: {
			required: false,
			type: "string",
			description: "The name of the file that must exist to activate the profile."
		}
	}
});
jsBind.addType("ReportPlugin",{
	properties: {
		groupId: {
			required: true,
			type: "string",
			description: "The group ID of the reporting plugin in the repository."
		},
		artifactId: {
			required: true,
			type: "string",
			description: "The artifact ID of the reporting plugin in the repository."
		},
		version: {
			required: false,
			type: "string",
			description: "The version of the reporting plugin to be used."
		},
		inherited: {
			required: false,
			type: "string",
			description: "Whether the configuration in this plugin should be made available to projects that inherit from this one."
		},
		configuration: {
			required: false,
			type: "string",
			description: "The configuration of the reporting plugin."
		},
		reportSets: {
			required: false,
			type: "ReportSet[]",
			description: "Multiple specifications of a set of reports, each having (possibly) different configuration. This is the reporting parallel to an <code>execution</code> in the build."
		}
	}
});
jsBind.addType("ReportSet",{
	properties: {
		id: {
			required: true,
			type: "string",
			description: "The unique id for this report set, to be used during POM inheritance and profile injection for merging of report sets."
		},
		configuration: {
			required: false,
			type: "string",
			description: "Configuration of the report to be used when generating this set."
		},
		inherited: {
			required: false,
			type: "string",
			description: "Whether any configuration should be propagated to child POMs."
		},
		reports: {
			required: true,
			type: "string[]",
			description: "The list of reports from this plugin which should be generated from this set."
		}
	}
});
jsBind.addType("Prerequisites",{
	properties: {
		maven: {
			required: false,
			type: "string",
			description: "The minimum version of Maven required to build the project, or to use this plugin."
		}
	}
});
jsBind.addType("Relocation",{
	properties: {
		groupId: {
			required: false,
			type: "string",
			description: "The group ID the artifact has moved to."
		},
		artifactId: {
			required: false,
			type: "string",
			description: "The new artifact ID of the artifact."
		},
		version: {
			required: false,
			type: "string",
			description: "The new version of the artifact."
		},
		message: {
			required: false,
			type: "string",
			description: "An additional message to show the user about the move, such as the reason."
		}
	}
});
jsBind.addType("Extension",{
	properties: {
		groupId: {
			required: true,
			type: "string",
			description: "The group ID of the extension's artifact."
		},
		artifactId: {
			required: true,
			type: "string",
			description: "The artifact ID of the extension."
		},
		version: {
			required: false,
			type: "string",
			description: "The version of the extension."
		}
	}
});
