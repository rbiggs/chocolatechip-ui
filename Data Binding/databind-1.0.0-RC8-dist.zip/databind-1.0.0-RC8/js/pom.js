/*
 * databind 1.0.0-RC8
 *
 * Copyright 2009 Arnd Brusdeilins <arnd@brusdeilins.net>
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 *
 */

var project=jsBind.createTypedVariable("Model","pom",{
		modelVersion: "4.0.0",
		parent: {
			artifactId: "master-pom",
			groupId: "de.ydev",
			version: "0.2",
			relativePath: "../arnd/master-pom/pom.xml",
		},
		groupId: "de.ydev.databind",
		artifactId: "databind",
		version: "0.9.17-SNAPSHOT",
		name: "Javascript Databinding",
		description: "Javascript Library for binding object to elements.",
		url: "http://docs.brusdeilins.net/databind",
		organization: {
			name: "Ydev",
			url: "http://www.brusdeilins.net",
		},
		licenses: [
			{
				name: "License Name",
				url: "file:///license",
				distribution: "manual",
				comments: "Comments",
			}
		],
		developers: [
			{
				id: "arnd",
				name: "Arnd Brusdeilins",
				email: "arnd@brusdeilins.net",
				url: "http://www.brusdeilins.net",
				organization: "freelancer",
				properties: [
					{key: "skypeId", value: "brusndeli"}
				],
			}
		],
		scm: {
			connection: "scm:svn:https://subversion.ydev.de/svn/databind/tags/databind-0.9.14",
			developerConnection: "scm:svn:https://subversion.ydev.de/svn/databind/tags/databind-0.9.14",
		},
		build: {
			sourceDirectory: "H:\\cygwin\\home\\dev\\projects\\databind\\src\\main\\java",
			scriptSourceDirectory: "src/main/scripts",
			testSourceDirectory: "H:\\cygwin\\home\\dev\\projects\\databind\\src\\test\\java",
			outputDirectory: "H:\\cygwin\\home\\dev\\projects\\databind\\target\\classes",
			testOutputDirectory: "H:\\cygwin\\home\\dev\\projects\\databind\\target\\test-classes",
			resources: [
				{
					targetPath: "xul",
					mergeId: "resource-2",
					directory: "H:\\cygwin\\home\\dev\\projects\\databind\\xul\\src\\main\\plugin",
				},
				{
					targetPath: "web",
					mergeId: "resource-3",
					directory: "H:\\cygwin\\home\\dev\\projects\\databind\\src\\main\\web",
				},
				{
					targetPath: "web/css/databind",
					mergeId: "resource-4",
					directory: "H:\\cygwin\\home\\dev\\projects\\databind\\src\\main\\css\\databind",
				},
				{
					targetPath: "xslt/databind/",
					mergeId: "resource-5",
					directory: "H:\\cygwin\\home\\dev\\projects\\databind\\src\\main\\xslt",
				}
			],
			testResources: [
				{
					mergeId: "resource-1",
					directory: "H:\\cygwin\\home\\dev\\projects\\databind\\src\\test\\resources",
				}
			],
			directory: "H:\\cygwin\\home\\dev\\projects\\databind\\target",
			finalName: "databind-0.9.17-SNAPSHOT",
			pluginManagement: {
				plugins: [
					{
						artifactId: "maven-antrun-plugin",
						version: "1.3",
					},
					{
						artifactId: "maven-assembly-plugin",
						version: "2.2-beta-2",
					},
					{
						artifactId: "maven-clean-plugin",
						version: "2.2",
					},
					{
						artifactId: "maven-compiler-plugin",
						version: "2.0.2",
					},
					{
						artifactId: "maven-dependency-plugin",
						version: "2.0",
					},
					{
						artifactId: "maven-deploy-plugin",
						version: "2.4",
					},
					{
						artifactId: "maven-ear-plugin",
						version: "2.3.1",
					},
					{
						artifactId: "maven-ejb-plugin",
						version: "2.1",
					},
					{
						artifactId: "maven-install-plugin",
						version: "2.2",
					},
					{
						artifactId: "maven-jar-plugin",
						version: "2.2",
					},
					{
						artifactId: "maven-javadoc-plugin",
						version: "2.5",
					},
					{
						artifactId: "maven-plugin-plugin",
						version: "2.5.1",
					},
					{
						artifactId: "maven-rar-plugin",
						version: "2.2",
					},
					{
						artifactId: "maven-release-plugin",
						version: "2.0-beta-8",
					},
					{
						artifactId: "maven-resources-plugin",
						version: "2.3",
					},
					{
						artifactId: "maven-site-plugin",
						version: "2.0-beta-7",
					},
					{
						artifactId: "maven-source-plugin",
						version: "2.0.4",
					},
					{
						artifactId: "maven-surefire-plugin",
						version: "2.4.3",
					},
					{
						artifactId: "maven-war-plugin",
						version: "2.1-alpha-2",
					},
					{
						groupId: "de.ydev.maven.plugins",
						artifactId: "maven-sitefix-plugin",
						executions: [
							{
								id: "site",
								phase: "site",
								goals: [
									"effective-site2",
									"decode",
									"site",
									"stage"
								],
							}
						],
						configuration: null,
					},
					{
						groupId: "org.codehaus.groovy.maven",
						artifactId: "gmaven-plugin",
						version: "1.0",
						executions: [
							{
								goals: [
									"generateStubs",
									"compile",
									"generateTestStubs",
									"testCompile"
								],
							}
						],
						configuration: null,
					}
				],
			},
			plugins: [
				{
					artifactId: "maven-antrun-plugin",
					version: "1.3",
					executions: [
						{
							phase: "prepare-package",
							goals: [
								"run"
							],
							configuration: null,
						}
					],
				},
				{
					artifactId: "maven-release-plugin",
					version: "2.0-beta-8",
					configuration: null,
				},
				{
					groupId: "de.ydev.dhtml",
					artifactId: "maven-dhtml-plugin",
					version: "0.9.8",
					executions: [
						{
							goals: [
								"unpackDependencies",
								"processScripts",
								"processCss",
								"transformXml",
								"rasterize",
								"filterImage"
							],
						}
					],
					configuration: null,
				},
				{
					groupId: "nl.windgazer",
					artifactId: "jsdoctk-plugin",
					version: "2.3.0-RC1",
					configuration: null,
				},
				{
					artifactId: "maven-dependency-plugin",
					version: "2.0",
					executions: [
						{
							phase: "prepare-package",
							goals: [
								"unpack-dependencies"
							],
							configuration: null,
						}
					],
				},
				{
					artifactId: "maven-compiler-plugin",
					version: "2.0.2",
					configuration: null,
				},
				{
					artifactId: "maven-site-plugin",
					version: "2.0.1",
					configuration: null,
				},
				{
					artifactId: "maven-help-plugin",
					version: "2.1",
				}
			],
		},
		distributionManagement: {
			repository: {
				id: "repo.brusdeilins.net",
				name: "Archiva Release Repository",
				url: "file:///usr/local/archiva/data/repositories/ydev/releases",
			},
			snapshotRepository: {
				id: "repo.brusdeilins.net",
				name: "Archiva Snapshot Repository",
				url: "file:///usr/local/archiva/data/repositories/ydev/snapshots",
			},
		},
		repositories: [
			{
				id: "jsdoctk1",
				url: "http://jsdoctk-plugin.googlecode.com/svn/repo",
			},
			{
				releases: {
					enabled: false,
				},
				snapshots: {
				},
				id: "snapshots.repo.brusdeilins.net",
				url: "http://archiva.ydev.de:8080/archiva/repository/ydev.snapshots",
			},
			{
				releases: {
				},
				snapshots: {
					enabled: false,
				},
				id: "releases.repo.brusdeilins.net",
				url: "http://archiva.ydev.de:8080/archiva/repository/ydev.releases",
			},
			{
				snapshots: {
					enabled: false,
				},
				id: "central",
				name: "Maven Repository Switchboard",
				url: "http://repo1.maven.org/maven2",
			}
		],
		pluginRepositories: [
			{
				id: "jsdoctk2",
				url: "http://jsdoctk-plugin.googlecode.com/svn/repo",
			},
			{
				releases: {
					enabled: false,
				},
				snapshots: {
				},
				id: "snapshots.repo.brusdeilins.net",
				url: "http://archiva.ydev.de:8080/archiva/repository/ydev.snapshots",
			},
			{
				releases: {
				},
				snapshots: {
					enabled: false,
				},
				id: "releases.repo.brusdeilins.net",
				url: "http://archiva.ydev.de:8080/archiva/repository/ydev.releases",
			},
			{
				releases: {
					updatePolicy: "never",
				},
				snapshots: {
					enabled: false,
				},
				id: "central",
				name: "Maven Plugin Repository",
				url: "http://repo1.maven.org/maven2",
			}
		],
		dependencies: [
			{
				groupId: "com.yahoo.platform.yui",
				artifactId: "javascript-compressor",
				version: "2.4.2",
			},
			{
				groupId: "de.ydev.dhtml",
				artifactId: "jquery",
				version: "1.4.2-1",
			},
			{
				groupId: "rhino",
				artifactId: "js",
				version: "1.7R2",
			},
			{
				groupId: "de.ydev.dhtml",
				artifactId: "tooltips",
				version: "0.9.4",
			},
			{
				groupId: "de.ydev.dhtml",
				artifactId: "firebug",
				version: "1.2-3",
			},
			{
				groupId: "net.sf.saxon",
				artifactId: "saxon",
				version: "9.1.0.2",
			},
			{
				groupId: "commons-logging",
				artifactId: "commons-logging",
				version: "1.0.4",
				scope: "compile",
			},
			{
				groupId: "log4j",
				artifactId: "log4j",
				version: "1.2.8",
				scope: "runtime",
			}
		],
		reporting: {
			outputDirectory: "H:\\cygwin\\home\\dev\\projects\\databind\\target/site",
			plugins: [
				{
					artifactId: "maven-project-info-reports-plugin",
					version: "2.1.2",
					reportSets: [
						{
							reports: [
								"index"
							],
						}
					],
				}
			],
		},
		dependencyManagement: {
			dependencies: [
				{
					groupId: "commons-beanutils",
					artifactId: "commons-beanutils",
					version: "1.8.0",
					scope: "compile",
				},
				{
					groupId: "commons-logging",
					artifactId: "commons-logging",
					version: "1.0.4",
					scope: "compile",
				},
				{
					groupId: "log4j",
					artifactId: "log4j",
					version: "1.2.8",
					scope: "runtime",
				}
			],
		},
		properties: [
			{key: "project.build.sourceEncoding", value: "utf-8"},
			{key: "project.reporting.outputEncoding", value: "utf-8"},
			{key: "stageDir", value: "c:/wamp/www/maven/docs"}
		]
	}
);
